package com.example.sravan.blink;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends Activity
{
    private Camera camera;
    private boolean isFlashOn;
    private boolean hasFlash;
    Parameters params;
    Button button;
    EditText data;
    public String input_string;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Button for sending bit sequence
        button = (Button)findViewById(R.id.button);
        //Field for entering text
        data = (EditText)findViewById(R.id.data);

        button.setOnClickListener(new View.OnClickListener()
                {
                    public void onClick(View view)
                    {
                        //Text input is stored in input string
                        input_string= data.getText().toString();
                        //The data in the field is cleared
                        data.setText("");

                        if (isFlashOn)
                            turnOffFlash();
                        else
                            turnOnFlash();
                    }
                }
        );

        // First check if device is supporting flashlight or not        
        hasFlash = getApplicationContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

            if (!hasFlash)
            {
                // device doesn't support flash
                // Show alert message and close the application
                AlertDialog alert = new AlertDialog.Builder(MainActivity.this).create();
                alert.setTitle("Error");
                alert.setMessage("Sorry, your device doesn't support flash light!");
                alert.setButton("OK", new DialogInterface.OnClickListener()
                    {
                        public void onClick(DialogInterface dialog, int which)
                        {
                            // closing the application
                            finish();
                        }
                    }
                );
            alert.show();
            return;
        }

        // Get the camera
        getCamera();
    }

    // Get the camera
    private void getCamera()
    {
        if (camera == null)
        {
            try
            {
                camera = Camera.open();
                params = camera.getParameters();
            }
            catch (RuntimeException e)
            {
                Log.e("Camera Error. Failed to Open. Error: ", e.getMessage());
            }
        }
    }

    // Turning On flash
    private void turnOnFlash()
    {
        isFlashOn = true;

        //Generation of bit sequence(Encoding)
        int length = input_string.length();
        int bit_sequence []=new int[7*length] ;
        for(int i=0; i<length; i++ )
        {
            int temp = (int)input_string.charAt(i);
            for(int t=0;t<7;t++)
            {
                if(temp%2==0)
                    bit_sequence[7*i+t]=0;
                else
                    bit_sequence[7*i+t]=1;
                temp=temp/2;
            }
        }

        long blinkDelay= 1; //Delay in milliseconds(not sure, need to check once)
        for (int i = 0; i < 7*length; i++)
        {
            if (bit_sequence[i] == 1)
            {
                params.setFlashMode(Parameters.FLASH_MODE_TORCH);
                camera.setParameters(params);
                camera.startPreview();
            }
            else
            {
                params.setFlashMode(Parameters.FLASH_MODE_OFF);
                camera.setParameters(params);
                camera.stopPreview();
            }
            try
            {
                Thread.sleep(blinkDelay);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }
        //Set flash to be off after sending the message
        turnOffFlash();
    }


    // Turning Off flash
    private void turnOffFlash()
    {
        if (isFlashOn)
        {
            if (camera == null || params == null)
            {
                return;
            }
            params = camera.getParameters();
            params.setFlashMode(Parameters.FLASH_MODE_OFF);
            camera.setParameters(params);
            camera.stopPreview();
            isFlashOn = false;
        }
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        turnOffFlash();
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        if(hasFlash)
           turnOffFlash();
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        getCamera();
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        // on stop release the camera
        if (camera != null)
        {
            camera.release();
            camera = null;
        }
    }
}